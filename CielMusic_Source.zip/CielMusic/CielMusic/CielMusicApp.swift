import SwiftUI

@main
struct CielMusicApp: App {
    @StateObject private var music = MusicPlayer()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(music)
                .preferredColorScheme(.dark)
        }
    }
}
