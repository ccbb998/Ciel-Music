import Foundation

struct Track: Identifiable, Equatable {
    let id: UUID
    let title: String
    let url: URL
    let isRemote: Bool

    init(title: String, url: URL, isRemote: Bool) {
        self.id = UUID()
        self.title = title
        self.url = url
        self.isRemote = isRemote
    }
}
