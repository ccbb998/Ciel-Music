# Ciel Music — iOS source project

Ứng dụng SwiftUI phát nhạc từ tệp âm thanh được nhập vào iPhone và từ URL HTTP/HTTPS trực tiếp.

## Tính năng hiện có
- Nhập nhiều tệp âm thanh từ ứng dụng Tệp; ứng dụng sao chép tệp vào vùng Documents riêng.
- Phát URL âm thanh trực tiếp (HTTP/HTTPS).
- Danh sách phát, chọn bài, bài trước/bài tiếp, tua, xóa bài.
- Cấu hình AVAudioSession `.playback` và điều khiển cơ bản từ màn hình khóa/tai nghe.
- Giao diện tối đen/tím.

## Yêu cầu
- Mac có Xcode (khuyến nghị phiên bản mới ổn định).
- iPhone chạy phiên bản iOS được Xcode đang dùng hỗ trợ.
- Cáp USB hoặc kết nối Wi‑Fi để chạy thử trên iPhone.

## Tạo project trong Xcode
1. Mở Xcode → File → New → Project → iOS → App.
2. Product Name: `CielMusic`; Interface: `SwiftUI`; Language: `Swift`.
3. Chọn bundle identifier riêng, ví dụ `com.tenban.CielMusic` (đổi `tenban` thành chuỗi riêng).
4. Xóa file `ContentView.swift` và file App Swift mặc định trong project vừa tạo, rồi kéo 4 file trong thư mục `CielMusic` của gói này vào project (chọn **Copy items if needed** và target CielMusic).
5. Chọn project → Target CielMusic → **Signing & Capabilities**:
   - Bật **Automatically manage signing**.
   - Chọn Team là Apple Account cá nhân của bạn.
   - Đảm bảo Bundle Identifier là duy nhất.
6. Chọn Target → **Info** → thêm key `Privacy - Media Library Usage Description` là không cần thiết cho bản này; app nhập file qua Document Picker nên không cần quyền thư viện nhạc.
7. Chọn Target → **Signing & Capabilities** → **+ Capability** → **Background Modes** → bật **Audio, AirPlay, and Picture in Picture** (tên có thể hơi khác theo phiên bản Xcode).
8. Chọn iPhone làm thiết bị đích, nhấn Run để cài thử.

## Xuất IPA
1. Trong Xcode chọn **Any iOS Device (arm64)** làm destination.
2. Chọn Product → Archive.
3. Khi Organizer mở, chọn archive vừa tạo → Distribute App.
4. Chọn phương thức phân phối phù hợp với tài khoản và mục đích. Xcode sẽ hướng dẫn ký và xuất gói cài đặt nếu phương thức đó hỗ trợ IPA.
5. Với cài đặt cá nhân, có thể dùng phương thức development/ad hoc phù hợp với thiết bị đã đăng ký. Làm theo màn hình Xcode; không dùng chứng chỉ hoặc hồ sơ ký không rõ nguồn gốc.

## Giới hạn và lưu ý
- URL online phải là URL trỏ trực tiếp tới luồng/tệp âm thanh mà máy chủ cho phép phát; trang web YouTube/Spotify hoặc trang nghe nhạc thông thường không phải URL âm thanh trực tiếp.
- Máy chủ HTTPS thường tương thích hơn HTTP. Một số máy chủ chặn phát ngoài trình duyệt, yêu cầu đăng nhập, hoặc không hỗ trợ định dạng/streaming mà AVPlayer hiểu được.
- Bản mẫu chưa có tìm kiếm catalog, tài khoản, lời bài hát, ảnh bìa, tải nhạc từ dịch vụ bên thứ ba hoặc đồng bộ đám mây.
- Phát nền cần bật Background Modes → Audio và thiết bị cần cho phép ứng dụng chạy nền.
- Không phân phối nhạc có bản quyền nếu bạn không có quyền sử dụng.
- Việc xuất IPA cần Xcode/macOS và ký ứng dụng. Gói mã nguồn này không phải IPA đã ký và không thể cài trực tiếp như ứng dụng hoàn chỉnh.
